#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100

int queue[MAX_SIZE];
int front = -1, rear = -1;

void enqueue(int data) {
    if (rear == MAX_SIZE - 1) {
        fprintf(stderr, "Error: Queue is full\n");
        exit(EXIT_FAILURE);
    }

    if (front == -1) {
        front = 0;
    }

    rear++;
    queue[rear] = data;
}

int dequeue() {
    if (front == -1) {
        fprintf(stderr, "Error: Queue is empty\n");
        exit(EXIT_FAILURE);
    }

    int data = queue[front];

    if (front == rear) {
        front = rear = -1;
    } else {
        front++;
    }

    return data;
}

void printQueue() {
    if (front == -1) {
        printf("Queue is empty\n");
        return;
    }

    printf("Queue elements: ");
    for (int i = front; i <= rear; i++) {
        printf("%d ", queue[i]);
    }
    printf("\n");
}

int main() {
    enqueue(10);
    enqueue(20);
    enqueue(30);

    printQueue();

    printf("Dequeue operation: %d", dequeue());

    printf("\nQueue elements after dequeue: \n");
    
    printQueue();

    return 0;
}
