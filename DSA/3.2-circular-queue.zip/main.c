#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 5

int circularQueue[MAX_SIZE];
int front = -1, rear = -1;

int isFull() {
    return (front == (rear + 1) % MAX_SIZE);
}

int isEmpty() {
    return (front == -1);
}

int size() {
    if (isEmpty()) {
        return 0;
    }
    return (rear >= front) ? (rear - front + 1) : (MAX_SIZE - front + rear + 1);
}

void enqueue(int data) {
    if (isFull()) {
        fprintf(stderr, "Error: Circular Queue is full\n");
        exit(EXIT_FAILURE);
    }

    if (isEmpty()) {
        front = rear = 0;
    } else {
        rear = (rear + 1) % MAX_SIZE;
    }

    circularQueue[rear] = data;
}

int dequeue() {
    if (isEmpty()) {
        fprintf(stderr, "Error: Circular Queue is empty\n");
        exit(EXIT_FAILURE);
    }

    int data = circularQueue[front];

    if (front == rear) {
        front = rear = -1;
    } else {
        front = (front + 1) % MAX_SIZE;
    }

    return data;
}

void printQueue() {
    if (isEmpty()) {
        printf("Circular Queue is empty\n");
        return;
    }

    printf("Circular Queue elements: ");
    int i = front;
    do {
        printf("%d ", circularQueue[i]);
        i = (i + 1) % MAX_SIZE;
    } while (i != (rear + 1) % MAX_SIZE);
    printf("\n");
}

int main() {
    // Enqueue
    enqueue(10);
    enqueue(20);
    enqueue(30);

    // Print queue elements
    printQueue();

    // Dequeue
    printf("Dequeue operation: %d\n", dequeue());

    // Print queue elements after dequeue
    printQueue();

    // Enqueue more elements
    enqueue(40);
    enqueue(50);

    // Print updated queue elements
    printQueue();

    // Check the size of the queue
    printf("Queue size: %d\n", size());

    return 0;
}
