#include <stdio.h>
#include <stdlib.h>

// Define a structure for a node in the stack
struct Node {
    int data;
    struct Node* next;
};

// Create a global variable to represent the top of the stack
struct Node* top = NULL;

int isEmpty() {
    return (top == NULL);
}

void push(int data) {
    // Create a new node
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        perror("Error in memory allocation");
        exit(EXIT_FAILURE);
    }
    newNode->data = data;

    // Set the new node's next pointer to the current top of the stack
    newNode->next = top;

    // Update the top of the stack to the new node
    top = newNode;
}

int pop() {
    if (isEmpty()) {
        fprintf(stderr, "Error: Stack is empty\n");
        return -1;  // Return a sentinel value to indicate an error
    }

    // Get the data from the top node
    int data = top->data;

    // Move the top pointer to the next node
    struct Node* temp = top;
    top = top->next;

    // Free the memory of the popped node
    free(temp);

    return data;
}

void display() {
    if (isEmpty()) {
        printf("Stack is empty\n");
        return;
    }

    printf("Stack elements: ");
    struct Node* current = top;
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}

int main() {
    int choice, data;

    do {
        printf("\nMenu:\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Display\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter data to push: ");
                scanf("%d", &data);
                push(data);
                break;
            case 2:
                data = pop();
                if (data != -1) {
                    printf("Popped element: %d\n", data);
                }
                break;
            case 3:
                display();
                break;
            case 4:
                printf("Exiting the program.\n");
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }

    } while (choice != 4);

    return 0;
}
