#include <stdio.h>
#include <stdlib.h>

// Define a structure for a node in the queue
struct Node {
    int data;
    struct Node* next;
};

// Define a structure for the linked queue
struct Queue {
    struct Node* front;
    struct Node* rear;
};

// Create a global variable to represent the front and rear of the queue
struct Queue myQueue;

// Function to check if the queue is empty
int isEmpty() {
    return (myQueue.front == NULL);
}

// Function to enqueue a new element
void enqueue(int data) {
    // Create a new node
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        perror("Error in memory allocation");
        exit(EXIT_FAILURE);
    }
    newNode->data = data;
    newNode->next = NULL;

    // If the queue is empty, set both front and rear to the new node
    if (isEmpty()) {
        myQueue.front = myQueue.rear = newNode;
    } else {
        // Otherwise, add the new node to the rear and update the rear pointer
        myQueue.rear->next = newNode;
        myQueue.rear = newNode;
    }
}

// Function to dequeue an element
int dequeue() {
    if (isEmpty()) {
        fprintf(stderr, "Error: Queue is empty\n");
        return -1;  // Return a sentinel value to indicate an error
    }

    // Get the data from the front node
    int data = myQueue.front->data;

    // Move the front pointer to the next node
    struct Node* temp = myQueue.front;
    myQueue.front = myQueue.front->next;

    // If the queue becomes empty after dequeue, update the rear pointer to NULL
    if (myQueue.front == NULL) {
        myQueue.rear = NULL;
    }

    // Free the memory of the dequeued node
    free(temp);

    return data;
}

// Function to display the elements of the queue
void display() {
    if (isEmpty()) {
        printf("Queue is empty\n");
        return;
    }

    printf("Queue elements: ");
    struct Node* current = myQueue.front;
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}

int main() {
    int choice, data;

    // Initialize the queue
    myQueue.front = myQueue.rear = NULL;

    do {
        printf("\nMenu:\n");
        printf("1. Enqueue\n");
        printf("2. Dequeue\n");
        printf("3. Display\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter data to enqueue: ");
                scanf("%d", &data);
                enqueue(data);
                break;
            case 2:
                data = dequeue();
                if (data != -1) {
                    printf("Dequeued element: %d\n", data);
                }
                break;
            case 3:
                display();
                break;
            case 4:
                printf("Exiting the program.\n");
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }

    } while (choice != 4);

    return 0;
}
