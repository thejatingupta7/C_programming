// BST 
// complexity : O(n) & {O(log n) for a balanced tree}

#include <stdio.h>
#include <stdlib.h>

typedef struct Tree{
    int data;
    struct Tree *left;
    struct Tree *right;
}Tree;

Tree *createnode(int data){
    Tree *root = (Tree*)malloc(sizeof(Tree));
    (root->data) = data;
    (root->left) = (root->right) = NULL;
    return root;
}

Tree *insertnode(Tree *root, int data){
    if(root==NULL){
        return createnode(data);
    }else{
        if(data<=(root->data)){
            root->left = insertnode(root->left, data);
        }else{
            root->right = insertnode(root->right, data);
        }
    }
}


Tree *deletenode(Tree *root, int data){
    if(root==NULL){
        return root;
    }
    if(data < (root->data))
        (root->left) = deletenode(root->left, data);
    else if(data > (root->data))
        (root->right) = deletenode(root->right, data);
    else{
        
        if((root->left)==NULL){
            Tree *temp = root->right;
            free(root);
            return temp;
        }else if((root->right)==NULL){
            Tree *temp = root->left;
            free(root);
            return temp;
        }
        
        Tree *temp = root->right;
        while(temp->left != NULL){
            temp=temp->left;
        }
        root->data = temp->data;
        root->right = deletenode(root->right, temp->data);
    }
    return root;
}

void display(Tree *root){
    if(root != NULL){
        display(root->left);
        printf("%d ", root->data);
        display(root->right);
    }
}

int main()
{
    Tree *n1 = createnode(1);
    insertnode(n1, 2);
    insertnode(n1, 3);
    insertnode(n1, 89);
    printf("Tree is as follows:\n");
    display(n1);
    
    n1 = deletenode(n1, 89);
    printf("\nTree after deletion is as follows:\n");
    display(n1);
    return 0;
}
