// BINARY SEARCH
// space : O(1)
// time complexity : O(log n)


#include <stdio.h>

int main()
{
    int arr[] = {1,2,3,4,6};
    int n = sizeof(arr)/sizeof(arr[0]);
    int target = 6;
    
    int low = 0, high = n-1;
    int found = 0;
    
    while(low<=high){
        
        int mid = (low+high)/2;
        
        if(arr[mid]==target){
            printf("Element found at index %d.", mid);
            found = 1;
            break;
        }
        else if(arr[mid]<target){
            low = mid + 1;
        }
        else{
            high = mid - 1;
        }
    }
    if(found == 0){
        printf("Element not found!");
    }
    
    return 0;
}

