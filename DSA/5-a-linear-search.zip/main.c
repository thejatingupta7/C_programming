// LINEAR SEARCH
// space : O(1)
// complexity : O(n)

#include <stdio.h>

int main()
{
    int arr[] = {1,2,56,76,5};
    int n = sizeof(arr)/sizeof(arr[0]);
    
    int target = 76;
    int count = 0;
    
    for(int i = 0; i < n; i++){
        if(arr[i]==target){
            printf("Element %d found at index %d of the array.", target, i);
            count = 1; 
            break;
        }
    }
    if(count == 0)
        printf("Element not Found!");
        
    return 0;
}
