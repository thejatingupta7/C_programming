// Selection sort 
// space : O(1)
// time complexity : O(n^2)

#include <stdio.h>

int main()
{
    int arr[]= {9,2,8,6,4};
    int n = sizeof(arr)/sizeof(arr[0]);
    
    for(int i = 0; i<n-1; i++){
        
        int min_index = i;
        for(int j = i+1; j<n; j++){
            if(arr[j]<arr[min_index])
                min_index=j;
        }
        
        int temp = arr[i];
        arr[i] = arr[min_index];
        arr[min_index] = temp;
    }
    
    printf("Sorted array:\n");
    for(int i = 0; i<n; i++){
        printf("%d ", arr[i]);
    }
    
    
    return 0;
}

