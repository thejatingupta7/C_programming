// Tree sort 
// space : O(n)
// time complexity : O(n^2)

#include <stdio.h>
#include <stdlib.h>

typedef struct Treenode{
    int data;
    struct Treenode *left;
    struct Treenode *right;
}Treenode;

void insert(Treenode **root, int data){
    if(*root == NULL){
        (*root) = (Treenode*)malloc(sizeof(Treenode));
        (*root)->data = data;
        (*root)->left = NULL;
        (*root)->right = NULL;
    }else{
        if(data<((*root)->data))
            insert(&((*root)->left), data);
        else
            insert(&((*root)->right), data);
    }
}

void inorder(Treenode *root){
    if(root!=NULL){
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

int main()
{
    int arr[]= {9,2,8,6,4};
    int n = sizeof(arr)/sizeof(arr[0]);
    
    Treenode *root = NULL;
    
    for(int i = 0; i<n; i++){
        insert(&root, arr[i]);
    }
    
    printf("Sorted array:\n");
    inorder(root);
    
    return 0;
}
