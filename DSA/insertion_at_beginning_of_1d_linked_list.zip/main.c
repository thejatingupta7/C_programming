// INSERTION AT BEGINNING OF A 1D LINKED LIST 

#include <stdio.h>
#include <stdlib.h>

typedef struct node{
    int data;
    struct node *next;
}Node;

int main()
{
    int n;
    Node *head, *temp1, *temp2;
    head = (Node*)malloc(sizeof(Node));
    printf("Enter head data: ");
    scanf("%d", &head->data);
    head->next=NULL;
    
    printf("Enter the number of nodes to be created: ");
    scanf("%d", &n);
    temp1=head;
    for(int i=0; i<n; i++){
        temp2=(Node*)malloc(sizeof(Node));
        printf("Enter data for node %d: ", (i+2));
        scanf("%d", &temp2->data);
        temp1->next=temp2;
        temp2->next=NULL;
        temp1=temp2;
    }
    
    //printing the linked list
    Node *temp;                
    temp=head;
    for(int i=0; i<=n; i++){
        printf("%d->", temp->data);
        if(i==n)
            printf("NULL\n");
        temp=temp->next;
    }
    
    //insertion at beginning 
    Node *newnode;
    newnode=(Node*)malloc(sizeof(Node));
    newnode->data=4;
    newnode->next=head;
    head=newnode;
    
    //printing the linked list again
    temp=head;
    printf("After inserting 4 at beginning\n");
    for(int i=0; i<=n+1; i++){
        printf("%d->", temp->data);
        if(i==n+1)
            printf("NULL\n");
        temp=temp->next;
    }
    
    
    return 0;
}


