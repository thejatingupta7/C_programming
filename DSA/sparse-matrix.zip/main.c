//SPARSE MATRIX 

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int rows, cols, a[10][10], b[10][10];
    printf("Enter the number of row in the matrix: ");
    scanf("%d", &rows);
    printf("Enter the number of columns in the matrix: ");
    scanf("%d", &cols);
    
    //input matrix 1
    printf("Input matrix 1:\n");
    for(int i=0; i<rows; i++){
        for(int j=0; j<cols; j++){
            printf("a[%d][%d]: ", i, j);
            scanf("%d", &a[i][j]);
        }
    }
    
    //input matrix 2
    printf("Input matrix 2:\n");
    for(int i=0; i<rows; i++){
        for(int j=0; j<cols; j++){
            printf("b[%d][%d]: ", i, j);
            scanf("%d", &b[i][j]);
        }
    }
    
    //check matrix 1 sparse or not
    int count1=0;
    for(int i=0; i<rows; i++){
        for(int j=0; j<cols; j++){
            if(a[i][j]==0)
                count1++;
        }
    }
    if(count1>((rows*cols)/2))
        printf("Matrix a is sparse\n");
    else
        printf("Matrix a is NOT sparse\n");
        
    //check matrix 2 sparse or not
    int count2=0;
    for(int i=0; i<rows; i++){
        for(int j=0; j<cols; j++){
            if(b[i][j]==0)
                count2++;
        }
    }
    if(count2>((rows*cols)/2))
        printf("Matrix b is sparse\n");
    else
        printf("Matrix b is NOT sparse\n");


    //adding and subtraction of matrix a & b
    int add[10][10], diff[10][10];
    for(int i=0; i<rows; i++){
        for(int j=0; j<cols; j++){
            add[i][j]=a[i][j]+b[i][j];
            diff[i][j]=a[i][j]-b[i][j];
        }
    }

   
    //printing sum
    printf("Sum of matrices: \n");
    for(int i=0; i<rows; i++){
        for(int j=0; j<cols; j++){
            printf("%d  ", add[i][j]);
        }
        printf("\n");
    }
    //printing difference
    printf("Difference of matrices: \n");
    for(int i=0; i<rows; i++){
        for(int j=0; j<cols; j++){
            printf("%d  ", diff[i][j]);
        }
        printf("\n");
    }
 
    

    return 0;
}
