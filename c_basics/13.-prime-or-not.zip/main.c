



#include <stdio.h>

int main()
{
    int i,j,c;
    printf("enter a number: ");
    scanf("%d",&j);
    
    for (i=1;i<=j;i++){
        if (j%i==0){
            c++;
        }}
    if(c==2){
        printf("%d is prime",j);}
        else
        printf("%d is not prime",j);
 }

    
