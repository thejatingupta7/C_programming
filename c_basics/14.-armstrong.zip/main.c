
// armstrong number condition : 153 = 1cube +5cube +3cube //
#include <stdio.h>

int main()
{
    int a,b,arm=0,tem;
    printf ("Enter a number: " );
    scanf ("%d",&a);
    
    tem=a;
    while (a>0){
    b=a%10;
    arm=arm+(b*b*b);
    a=a/10;}
    
    
    if(tem==arm){
        printf("Number is armstrong");}
    else{
        printf("is not");
        }
 
}

