/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void swap(int *a,int *b);
void main()
{
    int a,b;
    
    printf("enter a number: ");
    scanf("%d %d",&a,&b);
    printf("number before swapping are %d and %d \n",a,b);
    
    swap(&a,&b);
    
}

void swap(int *a,int *b){
    int tem;
    tem=*a;
    *a=*b;
    *b=tem;     
    printf("number after  swapping are %d and %d",*a,*b);}

