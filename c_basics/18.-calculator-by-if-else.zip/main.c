#include <stdio.h>

void main(){
       float a,b;
       float result;
       char operator;
       
       printf("choose an operator from '+', '-', '*', '/' \n");
       
       printf("Enter an operator : ");
       scanf("%c",&operator);
       printf("enter a number : ");
       scanf("%f",&a);
       printf("enter second number : ");
       scanf("%f",&b);
    
    if (operator == '+'){
        result=a+b;
        printf("%f + %f = %.2f",a,b,result);}
    else if (operator == '-'){
        result=a-b;
        printf("%f - %f = %.2f",a,b,result);}
    else if (operator == '*'){
        result=a*b;
        printf("%f * %f = %.2f",a,b,result);}
    else if (operator == '/')
        {while (b ==0)
            {printf("denominator can't be zero. Enter second number again : ");
            scanf("%f",&b);}
        result=a/b;
        printf("%f/%f = %.2f",a,b,result);}
    else
    printf ("wrong input");
}
