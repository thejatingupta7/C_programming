/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

int main()
{
    int i;
    char a[100];
    printf ("enter a string: ");
    scanf ("%s",&a);
   
   for(i=0;i<=strlen(a);i++){
       if (a[i]>=97 && a[i]<=122)
       {a[i] = a[i] - 32;}
   }
   printf ("\n upper case string is %s",a);
}
