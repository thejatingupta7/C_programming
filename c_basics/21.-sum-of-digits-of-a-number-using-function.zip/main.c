/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <conio.h>

int main()
{
    int num, result;
    printf("enter a number: ");
    scanf("%d", &num);
    
    result=sum(num);
    printf("sum of digits of %d is %d",num,result);
    return 0;
}

int sum(int num){
    if(num!=0){
        return(num%10 + sum(num/10));
    }
    else{
        return 0;
    }
}
