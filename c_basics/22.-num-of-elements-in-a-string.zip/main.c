/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char s[100];
    int i, count=0;
    
    printf("enter a string: ");
    gets(s);
    
    for (i=0;s[i]!='\0';i++){
        count = count + 1;
    }
    
    printf("no. of elements in entered string is %d", count);
    return 0;
}
