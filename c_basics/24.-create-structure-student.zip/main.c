/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

struct student{
    char name[100];
    int roll;
    float marks;
}s;

void main(){
    struct student s= {"arvind",1664,79.8};
    
    printf("name of student : %s \n",s.name);
    printf("roll no. of student : %d \n",s.roll);
    printf("marks of student : %f \n",s.marks);
}