


#include <stdio.h>

struct student{
        char name;
        int roll;
        float marks;}s[4];
        
void main(){
    int avg;
    for (int i=0; i<4 ; i++){
        printf("enter name: ");
        scanf("%s",&s[i].name);
        printf("enter roll: ");
        scanf("%d",&s[i].roll);
        printf("enter marks: ");
        scanf("%f",&s[i].marks); 
        avg += s[i].marks;
    }    
    
    avg = avg/4;
    printf("the average marks : %d",avg);
}

