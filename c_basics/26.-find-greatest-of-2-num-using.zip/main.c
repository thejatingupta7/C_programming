

#include <stdio.h>
#define MAX(x,y)(x>y?x:y)

int main(){
    int a,b;
    printf("Enter first number : ");
    scanf ("%d",&a);
    printf("Enter second number : ");
    scanf ("%d",&b);
    
    printf("biggest of %d and %d is %d",a,b,MAX(a,b));
}