



#include <stdio.h>
#include <string.h>
int main( )
{
    char arr[100];
    int i;
    printf("Enter a string : ");
    scanf("%s",&arr[i]);
    int len;
    len = strlen ( arr ) ;
    printf ("Length of entered string = %d",len) ;
    return 0;
}