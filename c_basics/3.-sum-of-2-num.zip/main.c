#include <conio.h>
#include <stdio.h>

int main()
{
    int a,b,c;
    printf("enter a= ");
    scanf("%d",&a);
    printf("enter b= ");
    scanf("%d",&b);
    c=a+b;
    printf("the value of c is %d",c);

    return 0;
}
